﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(WebBanSon.Startup))]
namespace WebBanSon
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
